import { Game as Self } from "./chess";

import { withTranslation } from "react-i18next";

export const Game = withTranslation()(Self);
