import React from "react";

import "./homePage.styles.css";

export default function Home(props) {
  return (
    <div className="background">
      <div className="container"></div>
    </div>
  );
}
